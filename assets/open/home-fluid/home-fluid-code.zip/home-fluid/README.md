# Fluid solver demo (the home page hero)

A real-time 2-D incompressible fluid / flame simulation in one file of vanilla WebGL2: `fluid.js`. No libraries, no network.
This folder is exactly the code that runs behind the home page headline of the portfolio, plus a minimal page to run it.

## Run it
ES modules do not load from `file://`, so serve the folder (any static server):

    python3 -m http.server 8000      # then open http://localhost:8000/

Needs a browser with WebGL2 and float colour buffers. Without them (or with `?nowebgl=1`) `streamlines.js` (included, Canvas2D) is used instead.
Debug switches: `?fluidtier=0..3` forces a quality tier, `?nowebgl=1` forces the fallback.

## How it works
Stable fluids (Stam), entirely in fragment shaders, one frame is:
1. semi-Lagrangian / MacCormack advection of velocity, dye and temperature;
2. forces: temperature buoyancy (hot gas rises), vorticity confinement, a burner plume, pointer splats, click bursts, scroll stirring, idle forcing;
3. divergence, a Jacobi pressure solve, and gradient subtraction (makes the velocity divergence free);
4. a cylinder obstacle (no-through, no-slip) that sheds a Karman-style vortex street;
5. a render pass: temperature and dye are colour graded into a flame palette, then bloom, a slight chromatic fringe, film grain and a vignette.
Four quality tiers (simulation grid 192 / 128 / 96 / 64, 24 / 16 / 10 / 6 pressure iterations) are chosen from the device and adapted from measured frame times.
It pauses off screen and in hidden tabs. With `prefers-reduced-motion` (or `<html data-fx="off">`) it warms up and shows one still frame.

## Use it on your own page (plain HTML or a Jekyll site)
1. Copy `fluid.js` and `streamlines.js` to the same folder, e.g. `assets/js/hero/`.
2. Add the element. The canvas needs to fill its parent, and the text you want kept readable gets the classes below
   (the solver dims the field behind `.hero__name, .hero__tagline, .hero__cta`; pass `textRect` to change that):

       <div class="hero" id="hero">
         <canvas class="hero__canvas" aria-hidden="true"></canvas>
         <div class="hero__inner"><h1 class="hero__name">Your name</h1></div>
       </div>

3. Mount it. In Jekyll put this in a layout or include (the path goes through `relative_url`):

       <script type="module">
         import { mount } from "{{ '/assets/js/hero/fluid.js' | relative_url }}";
         const hero = await mount(document.getElementById("hero"), {});
         // hero.pause(); hero.resume(); hero.destroy();
       </script>

4. Colours come from the CSS variables `--bg --viewport --teal --amber --rose --sky` (see `index.html`), read at mount and on every
   `data-theme` change on `<html>`; light backgrounds switch to an ink-and-flame mapping.

Options: `mount(el, { tier, textRect, dprCap, reducedMotion })`, all optional. The first lines of `fluid.js` document them.

## Licence
Code: MIT, see `LICENSE`.
